package de.bredex.kurse.java2.annotations;

public class AnnotationTest {

}
