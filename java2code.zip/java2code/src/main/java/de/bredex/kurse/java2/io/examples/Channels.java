package de.bredex.kurse.java2.io.examples;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class Channels {
    
    public static void main(String[] args) throws IOException {
        //(@body@)
        // Streams erstellen
        FileInputStream eingabeStream = new FileInputStream("data/in.txt");
        FileOutputStream ausgabeStream = new FileOutputStream("data/out.txt");
        // Channels holen
        FileChannel eingabeChannel = eingabeStream.getChannel();
        FileChannel ausgabeChannel = ausgabeStream.getChannel();
        // Buffer erzeugen
        ByteBuffer buffer = ByteBuffer.allocate(10);
        // Einlesen und Ausgeben
        int geleseneBytes = eingabeChannel.read(buffer);
        while (geleseneBytes != -1) {
            buffer.flip(); // Umschalten zwischen Lesen und Schreiben
            ausgabeChannel.write(buffer);
            buffer.clear(); // Zuruecksetzen
            geleseneBytes = eingabeChannel.read(buffer);
        }
        // Channels (und Streams) schliessen
        ausgabeChannel.close();
        eingabeChannel.close();
        //(@/body@)
    }

}
