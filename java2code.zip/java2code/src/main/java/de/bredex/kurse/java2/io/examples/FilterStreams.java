package de.bredex.kurse.java2.io.examples;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.GZIPInputStream;

public class FilterStreams {
    
    public static void main(String[] args) throws IOException {
        //(@body@)
    	InputStream komprimiert = new FileInputStream("data/in.gz");
    	InputStream gepuffert = new BufferedInputStream(komprimiert);
    	InputStream daten = new GZIPInputStream(gepuffert);

    	int einzelByte;
    	do {
    	    einzelByte = daten.read();
        	if (einzelByte != -1) {
        	    System.out.write(einzelByte);
        	}
    	} while (einzelByte != -1); // Dateiende
    	// Puffer vor Programmende leeren
    	System.out.flush();
    	
    	daten.close();
        //(@/body@)
    }

}
