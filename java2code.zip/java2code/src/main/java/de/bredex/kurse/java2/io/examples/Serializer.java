package de.bredex.kurse.java2.io.examples;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.time.LocalDate;

public class Serializer {

    public static void main(String[] args) throws IOException {
        //(@body@)
        // Daten erstellen
        String einString = "Hallo Welt!";
        LocalDate einDatum = LocalDate.now();
        Integer eineZahl = 4711;
        
        // Stream zum Serialisieren in eine Datei erstellen
        OutputStream serialisiert = new FileOutputStream("data/serialized.data");
        ObjectOutputStream objekte = new ObjectOutputStream(serialisiert);
        // Daten schreiben
        objekte.writeObject(einString);
        objekte.writeObject(einDatum);
        objekte.writeObject(eineZahl);
        // Stream schliessen
        objekte.close();
        //(@/body@)
    }

}
