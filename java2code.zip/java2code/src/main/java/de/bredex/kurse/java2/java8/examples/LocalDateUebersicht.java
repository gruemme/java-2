package de.bredex.kurse.java2.java8.examples;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;

public class LocalDateUebersicht {

	public static void main(String[] args) {

		
		localDateExamples();
		localTimeExamples();
		localDateTimeExamples();
		adjustDateTime();

	}


	/**
	 * Die Klasse LocalDateTime kombiniert LocalTime und LocalDate 
	 * und bietet ein Datum (Jahr, Monat, Tag) + die 
	 * Zeit (Stunde, Minute, Sekunde, Nanosekunde).
	 */
	@SuppressWarnings("unused")
	private static void localDateTimeExamples() {
		// Aktuelles Datum inkl. Zeit
		LocalDateTime currentDateTime = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
		System.out.println(currentDateTime.format(formatter));
		formatter = DateTimeFormatter.ofPattern("hh:mm:ss");
		System.out.println(currentDateTime.format(formatter));
		formatter = DateTimeFormatter.ofPattern("'Es ist 'HH:mm 'Uhr' 'am' dd.mm.u '('G')'");
		System.out.println(currentDateTime.format(formatter));
		formatter = DateTimeFormatter.ofPattern("EEEE, dd.MMMM y");
		System.out.println(currentDateTime.format(formatter));
		 
		// 02.10.2014 12:30 Uhr
		LocalDateTime secondAug2014 = LocalDateTime.of(2014, 10, 2, 12, 30);
		 
		// 24.12.2014 - 12:00 Uhr
		LocalDateTime christmas2014 = LocalDateTime.of(2014, Month.DECEMBER, 24, 12, 0);
		
		//Informationen über das Datum und die Zeit
		LocalDate date = LocalDate.of(2014, 2, 15); // 15.02.2014
		 
		boolean isBefore = LocalDate.now().isBefore(date); // false
		 
		// Informationen über den Monat
		Month february = date.getMonth(); // Februar
		int februaryIntValue = february.getValue(); // 2
		int minLength = february.minLength(); // 28
		int maxLength = february.maxLength(); // 29 (wegen dem Schaltjahr)
		Month firstMonthOfQuarter = february.firstMonthOfQuarter(); // Januar, erster Monat im Quartal
		 
		// Informationen über das Jahr
		int year = date.getYear(); // 2014
		int dayOfYear = date.getDayOfYear(); // 46
		int lengthOfYear = date.lengthOfYear(); // 365
		boolean isLeapYear = date.isLeapYear(); // false (kein Schaltjahr)
		 
		DayOfWeek dayOfWeek = date.getDayOfWeek();
		int dayOfWeekIntValue = dayOfWeek.getValue(); // 6
		String dayOfWeekName = dayOfWeek.name(); // SATURDAY
		 
		int dayOfMonth = date.getDayOfMonth(); // 15
		LocalDateTime startOfDay = date.atStartOfDay(); // 15.02.2014 00:00 Uhr

	}

	@SuppressWarnings("unused")
	private static void localTimeExamples() {

		LocalTime currentTime = LocalTime.now(); // Aktuelle Zeit
		LocalTime midday = LocalTime.of(12, 0); // 12:00 Uhr
		LocalTime afterMidday = LocalTime.of(13, 30, 15); // 13:30:15 Uhr

		// 12345. Sekunde am Tag (03:25:45 Uhr)
		LocalTime fromSecondsOfDay = LocalTime.ofSecondOfDay(12345);

	}

	@SuppressWarnings("unused")
	private static void localDateExamples() {
		// das aktuelle Datum
		LocalDate currentDate = LocalDate.now();

		// Ist das aktuelle Jahr ein Schaltjahr?
		boolean isLeapYear = currentDate.isLeapYear();

		// 10.02.2014
		LocalDate tenthFeb2014 = LocalDate.of(2014, Month.FEBRUARY, 10);

		// Monate starten bei 1, 01.08.2014
		LocalDate firstAug2014 = LocalDate.of(2014, 8, 1);

		// Der 65. Tag in 2010 (06.03.2010)
		LocalDate sixtyFifthDayOf2010 = LocalDate.ofYearDay(2010, 65);
	}

	@SuppressWarnings("unused")
	private static void adjustDateTime() {
		// Informationen über eine Zeit
		LocalTime time = LocalTime.of(15, 30); // 15:30:00 Uhr
		int hour = time.getHour(); // 15
		int second = time.getSecond(); // 0
		int minute = time.getMinute(); // 30
		int secondOfDay = time.toSecondOfDay(); // 55800

		// Datum/Zeit manipulieren

		// Morgen
		LocalDate tomorrow = LocalDate.now().plusDays(1);
		 
		// Vor 5 Stunden und 30 Minuten
		LocalDateTime dateTime = LocalDateTime.now().minusHours(5).minusMinutes(30);
		
		//Ebenfalls nützlich zur Manipulation sind die TemporalAdjusters. Dazu importen wir java.time.temporal.TemporalAdjusters.*.

		LocalDate date = LocalDate.of(2014, Month.FEBRUARY, 25); // 25.02.2014
		 
		// Erster Tag im Februar - 01.02.2014
		LocalDate firstDayOfMonth = date.with(TemporalAdjusters.firstDayOfMonth());
		 
		// Letzter Tag im Februar - 28.02.2014
		LocalDate lastDayOfMonth = date.with(TemporalAdjusters.lastDayOfMonth());

	}

}
