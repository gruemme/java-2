package de.bredex.kurse.java2.io.examples;

public class SimpleSystemReadMultiCharacter {
	
	private static final int VALUE_OF_ENTER = 13;

	public static void main(String[] args) throws Exception {
		
		int enteredValue;
		System.out.println("Bitte mehrere Zeichen eingeben: ");
		
		String str = "";
		
		while ((enteredValue = System.in.read()) != VALUE_OF_ENTER) { 
			System.out.println((char) enteredValue);
			str = str + (char) enteredValue;
		}
		System.out.println(str);
	}
}








/**
while ((enteredValue = System.in.read()) != VALUE_OF_ENTER) { 
System.out.println((char) enteredValue);
//str = str + (char) enteredValue;
}
//System.out.println("Als kompletter String: " + str);

**/