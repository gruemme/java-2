package de.bredex.kurse.java2.io;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class Uebung1 {

    public List<String> readLinesFromInputStream(InputStream stream) throws IOException {
        return null;
    }

}
