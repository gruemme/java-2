package de.bredex.kurse.java2.concurrency;

import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.Test;


public class StackTest {

	static final int numRuns = 10;
	static SyncStack<String> stack = new SyncStack<>();
	static int lastValue = -1;

	static class ReaderThread extends Thread {
		@Override
		public void run() {
			System.err.println("reader started");
			for (int i = 0; i < numRuns; ++i) {
				String value = stack.pop();
				System.err.println("read " + value);
				try {
					lastValue = Integer.parseInt(value);
				} catch (NumberFormatException e) {
					// just ignore
				}
			}
		}
	}

	static class WriteThread extends Thread {
		@Override
		public void run() {
			System.err.println("writer started");
			for (int i = 0; i < numRuns; ++i) {
				stack.push(Integer.toString(i));
                System.err.println("write " + i);
			}
		}
	}

	@Test
	public void test() throws InterruptedException {
		ReaderThread r = new ReaderThread();
		WriteThread w = new WriteThread();
		r.start();
		delay(1000);
		w.start();
		// wait for reader to do its work
		r.join();
		w.join();
		assertNotEquals(lastValue, -1, "no values read");
	}

	private static void delay(int mSec) {
		try {
			Thread.sleep(mSec);
		} catch (InterruptedException e) {
			// sloppy implementation, just ignore interruptions
		}

	}

}
