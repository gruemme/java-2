package de.bredex.kurse.java2.generics.examples;

public class Person {

}
