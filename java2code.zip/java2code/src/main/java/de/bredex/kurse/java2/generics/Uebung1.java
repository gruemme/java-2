package de.bredex.kurse.java2.generics;

public class Uebung1 {

	public static <T> T getLastElement(T[] array) {
		return null;
	}

}
