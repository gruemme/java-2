package de.bredex.kurse.java2.junit.examples;

public class MyNumberUtil {
	public static boolean isEven(final int i) {
		return 0 == i % 2; // returns true for even numbers
	}
}
