package de.bredex.kurse.java2.java8.examples;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;

import de.bredex.kurse.java2.java8.examples.Country.Continent;

public class CountryTest {

	@Test
	public void testCountryStream() {
		Country deutschland = new Country("Deutschland", Continent.Europa);
		Country algerien = new Country("Algerien", Continent.Afrika);
		Country england = new Country("England", Continent.Europa);
		
		List<Country> countries = new ArrayList<>();
		countries.add(deutschland);
		countries.add(algerien);
		countries.add(england);
		
		// Liste in einen Stream umwandeln
		Stream<Country> countryStream = countries.stream();
		printStream(countryStream);
		
		// aus Country-Stream einen Continent-Stream erstellen
		Stream<Continent> continentStream = countries.stream().map(country -> country.continent);
		printStream(continentStream);
		
		// doppelte Eintraege aus Continent-Stream entfernen
		Stream<Continent> distinctContinentStream = countries.stream().map(country -> country.continent).distinct();
		printStream(distinctContinentStream);

		System.out.println();
		System.out.println();
		
		// Kontinente ausgeben
		countries.stream().map(country -> country.continent).distinct().forEach(continent -> System.out.println(continent));
	}
	
	private void printStream(Stream<?> stream) {
		Object[] array = stream.toArray();
		for (Object no : array) {
			System.out.print(no + "; ");
		}
		System.out.println(); // line break
	}
}
