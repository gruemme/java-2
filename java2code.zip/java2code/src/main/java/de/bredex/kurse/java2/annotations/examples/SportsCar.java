package de.bredex.kurse.java2.annotations.examples;

/**
 * This sports car can start the motor.
 */
public class SportsCar implements Car {

	@Override
	public void startMotor() {
		System.out.println("start motor of sports car");
	}

}
