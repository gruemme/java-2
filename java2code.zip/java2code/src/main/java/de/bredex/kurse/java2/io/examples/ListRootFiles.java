package de.bredex.kurse.java2.io.examples;

import java.io.IOException;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;

public class ListRootFiles {
    
    public static void main(String[] args) {
        //(@body@)
        FileSystem fileSystem = FileSystems.getDefault();
        for (Path path : fileSystem.getRootDirectories()) {
            try {
                long unterverzeichnisse = Files.list(path).filter(t -> Files.isDirectory(t)).count();
                System.out.println(path + " hat " + unterverzeichnisse + " Unterverzeichnisse.");
            } catch (IOException e) {
                System.out.println("Auf " + path + " kann nicht zugegriffen werden.");
            }
        }
        //(@/body@)
    }

}
