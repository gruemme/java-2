package de.bredex.kurse.java2.threads;

public class MessageProvider {

	public void addMessage(String message) {
	}

	public String getMessage() {
		return null;
	}

}
