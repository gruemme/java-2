package de.bredex.kurse.java2.io.examples;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;

public class ReaderWriterUmwandlung {
    
    public static void main(String[] args) throws IOException {
        //(@body@)
        InputStream eingabeStream = new FileInputStream("data/in.txt");
        OutputStream ausgabeStream = new FileOutputStream("data/out.txt");
        // Umwandlung in Reader/Writer
        Reader eingabe = new InputStreamReader(eingabeStream);
        Writer ausgabe = new OutputStreamWriter(ausgabeStream);
        // Eingabe puffern um ganze Zeilen lesen zu können
        BufferedReader gepufferteEingabe = new BufferedReader(eingabe);
        
        String zeile = gepufferteEingabe.readLine();
        int zeilenNummer = 1;
        while (zeile != null) { // solange neue Zeile vorhanden
            System.out.println(zeile);
            ausgabe.write(zeilenNummer + ": " + zeile);
            ausgabe.write(System.getProperty("line.separator"));
            // nächste Zeile lesen
            zeilenNummer++;
            zeile = gepufferteEingabe.readLine();
        }
        
        gepufferteEingabe.close();
        ausgabe.close();
        //(@/body@)
    }

}
