package de.bredex.kurse.java2.io.examples;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.zip.GZIPOutputStream;

public class FilterStreamsPrepare {
    
    public static void main(String[] args) throws IOException {
        OutputStream eingabe = new FileOutputStream("data/in.gz");
        OutputStream komprimiert = new GZIPOutputStream(eingabe);

        Writer writer = new OutputStreamWriter(komprimiert);
        writer.write("Dieser Text wird komprimiert.");
        
        writer.close();
    }

}
