package de.bredex.kurse.java2.java8.examples;

public class Country {
	
	enum Continent {
		Europa, Afrika
	}
	
	public Continent continent;
	private String name;
	
	public Country(String countryName, Continent countryContinent) {
		name = countryName;
		continent = countryContinent;
	}
	
	@Override
	public String toString() {
		return name;
	}
}
