package de.bredex.kurse.java2.junit;

public class Motor {

	private int roundsPerMinute;

	/**
	 * @return The current engine speed in rounds per minute.
	 */
	public int getRoundsPerMinute() {
		return roundsPerMinute;
	}

	public void start() {
		if (roundsPerMinute == 0) {
			roundsPerMinute = 1000;
			System.out.println("Motor started: " + roundsPerMinute + " rpm");
		} else {
			System.out.println("Motor already running.");
		}
	}

	public void stop() {
		roundsPerMinute = 0;
		System.out.println("Motor stopped: " + roundsPerMinute + " rpm");
	}

	/**
	 * @param deltaRoundsPerMinute
	 *            The amount of rounds per minute to change the engine speed.
	 */
	public void accelerateBy(final int deltaRoundsPerMinute) {
		if (roundsPerMinute > 0) {
			roundsPerMinute = roundsPerMinute + deltaRoundsPerMinute;
			if (roundsPerMinute < 750) {
				roundsPerMinute = 0; // turn off, if lower than minimum rpm
				// TODO: hier fuer Aufgabe 3 etwas hinzufuegen
			}
			System.out.println("Motor accelerated by " + deltaRoundsPerMinute
					+ " to " + roundsPerMinute + " rpm");
		} else {
			System.out.println("Motor is not running.");
		}
	}

}
