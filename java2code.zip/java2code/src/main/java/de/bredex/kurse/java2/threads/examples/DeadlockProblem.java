package de.bredex.kurse.java2.threads.examples;

public class DeadlockProblem {
	public static Object Auto = new Object();
	public static Object Schluessel = new Object();

	public static void main(String args[]) {
		Thread1 t1 = new Thread1();
		Thread2 t2 = new Thread2();
		t1.start();
		t2.start();
	}

	private static class Thread1 extends Thread {
		public void run() {
			synchronized (Schluessel) {
				System.out.println("Thread 1: Nimm Schluessel...");

				try {
					Thread.sleep(10);
				} catch (InterruptedException e) {
					// error
				}
				System.out.println("Thread 1: Reserviere Auto...");

				synchronized (Auto) {
					System.out.println("Thread 1: Benutze Auto und Schluessel...");
				}
			}
		}
	}
	
	private static class Thread2 extends Thread {
		public void run() {
			synchronized (Auto) {
				System.out.println("Thread 2: Reserviere Auto...");

				try {
					Thread.sleep(10);
				} catch (InterruptedException e) {
					// error
				}
				System.out.println("Thread 2: Nimm Schluessel...");

				synchronized (Schluessel) {
					System.out.println("Thread 2: Benutze Auto und Schluessel...");
				}
			}
		}
	}
}
