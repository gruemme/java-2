package de.bredex.kurse.java2.generics.examples;

public class LinkedNode<T> {

	private T value_;
	private LinkedNode<T> next_;

	public LinkedNode(T value) {
		value_ = value;
	}

	public T getValue() {
		return value_;
	}

	public void setNext(LinkedNode<T> next) {
		next_ = next;
	}

	public LinkedNode<T> getNext() {
		return next_;
	}

}
