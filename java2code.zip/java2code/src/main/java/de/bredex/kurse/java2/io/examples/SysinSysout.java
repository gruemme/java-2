package de.bredex.kurse.java2.io.examples;

import java.io.IOException;

public class SysinSysout {
    
    public static void main(String[] args) throws IOException {
        //(@body@)
        System.out.println("Geben Sie etwas ein!");
        int einByte;
        do {
            einByte = System.in.read();
            System.out.write(einByte);
        } while (einByte != 13 && einByte != 10); // Ende bei <ENTER>
        System.out.println("Programm beendet!");
        //(@/body@)
    }

}
