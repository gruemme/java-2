package de.bredex.kurse.java2.concurrency.examples;

import java.util.concurrent.Semaphore;

public class SemaphoreExample {

	static Semaphore semaphore = new Semaphore(2/* , true */); // acquire beruecksichtigt nicht, wer am laengsten wartet
	static Runnable r = new Runnable() {
		@Override
		public void run() {
			while (true) {
				try {
					// Versucht, in den kritischen Block einzutreten. 
					// Wenn der gerade belegt ist, wird gewartet. 
					// Vermindert die Menge der Erlaubnisse um eins. 
					semaphore.acquire();
					try {
						System.out.println(
								"Thread=" + Thread.currentThread().getName()
								+ ", Verfügbare Threads im Block: " + semaphore.availablePermits());
						
						Thread.sleep(2000);
					} finally {
						// Verlaesst den kritischen Abschnitt und legt eine Erlaubnis zurueck. 
						semaphore.release();
					}
				} catch (InterruptedException e) {
					e.printStackTrace();
					Thread.currentThread().interrupt();
					break;
				}
			}
		}
	};

	public static void main(String[] args) {
		new Thread(r).start();
		new Thread(r).start();
		new Thread(r).start();
	}
}
