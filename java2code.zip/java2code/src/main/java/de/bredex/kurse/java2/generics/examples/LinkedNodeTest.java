package de.bredex.kurse.java2.generics.examples;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class LinkedNodeTest {

	@Test
	public void testGetValueWithInteger() {
		LinkedNode<Integer> node = new LinkedNode<>(42);
		Assertions.assertEquals(Integer.valueOf(42), node.getValue());
	}

	@Test
	public void testGetValueWithStrings() {
		LinkedNode<String> node = new LinkedNode<>("hallo");
        Assertions.assertEquals("hallo", node.getValue());
	}
	
	@Test
	public void testGetNextValueWithString() {
	    LinkedNode<String> first = new LinkedNode<>("first");
	    LinkedNode<String> second = new LinkedNode<>("second");
	    first.setNext(second);
	    Assertions.assertEquals("second", first.getNext().getValue());
	}

}
