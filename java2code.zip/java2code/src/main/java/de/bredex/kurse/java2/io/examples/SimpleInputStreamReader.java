package de.bredex.kurse.java2.io.examples;

import java.io.InputStreamReader;

public class SimpleInputStreamReader {
	public static void main(String[] args) throws Exception {
		System.out.println("Bitte Zeichen eingeben: ");
		
		InputStreamReader inputStreamReader = new InputStreamReader(System.in);
		
		int enteredValue = inputStreamReader.read();
		
		while(enteredValue != 13){
		    char theChar = (char) enteredValue;
		    
		    System.out.println(theChar);
		    
		    // nächsten Wert zuweisen
		    enteredValue = inputStreamReader.read();
		}
		inputStreamReader.close();
	}
}
