package de.bredex.kurse.java2.annotations.examples;

interface Car {
	/**
	 * Starts the motor of the car.
	 */
	void startMotor();
}
