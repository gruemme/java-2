package de.bredex.kurse.java2.concurrency;

import java.util.Stack;
import java.util.concurrent.Semaphore;

public class SyncStack<T> {
    
    private Stack<T> stack = new Stack<>();
    private Semaphore semaphore = new Semaphore(0);
	
	public void push(T value) {
		stack.push(value);
		semaphore.release();
	}
	
	public T pop() {
	    try {
            semaphore.acquire();
            return stack.pop();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
	}

}
