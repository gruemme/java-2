package de.bredex.kurse.java2.io;

public class Uebung2 {
    
    public String getSmallDirectoryPath() {
        return "data";
    }
    
    public String getBigDirectoryPath() {
        return "..";
    }
    
    public long getDirectorySizeWithIO(String directoryPath) {
        return -1;
    }
    
    public long getDirectorySizeWithNIO(String directoryPath) {
    	return -2;
    }

}
