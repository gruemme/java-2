package de.bredex.kurse.java2.io.examples;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

//(@ohnemain1@)
public class SerializableClass implements Serializable {
    
    private String name;
    private transient String nichtSerialisiert;
    
    public SerializableClass(String _name, String _nichtSerialisiert) {
        name = _name;
        nichtSerialisiert = _nichtSerialisiert;
    }

    private void writeObject(ObjectOutputStream stream) throws IOException {
        stream.defaultWriteObject();
    }
    
    private void readObject(ObjectInputStream stream) throws ClassNotFoundException, IOException {
        stream.defaultReadObject();
        nichtSerialisiert = "Standardwert";
    }
//(@/ohnemain1@)

    @Override
    public String toString() {
        return name + ", " + nichtSerialisiert;
    }
    
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        SerializableClass serialisierbaresObjekt = new SerializableClass("Java", "Kurs");
        System.out.println("Vor der Serialisierung: " + serialisierbaresObjekt);

        // Serialisieren
        ByteArrayOutputStream byteStream1 = new ByteArrayOutputStream();
        ObjectOutputStream objekte1 = new ObjectOutputStream(byteStream1);
        objekte1.writeObject(serialisierbaresObjekt);
        byte[] bytes = byteStream1.toByteArray();
        objekte1.close();
        // Deserialisieren
        ByteArrayInputStream byteStream2 = new ByteArrayInputStream(bytes);
        ObjectInputStream objekte2 = new ObjectInputStream(byteStream2);
        serialisierbaresObjekt = (SerializableClass) objekte2.readObject();
        objekte2.close();
        
        System.out.println("Nach der Serialisierung: " + serialisierbaresObjekt);
    }

//(@ohnemain2@)
}
//(@/ohnemain2@)
