package de.bredex.kurse.java2.generics.examples;
import java.util.ArrayList;
import java.util.List;

public class TestPersonChild {

	public static void main(String[] args) {
		List<Person> personList = new ArrayList<>();
		List<Child> childList = new ArrayList<>();
		List<Object> objectList = new ArrayList<>();
		getYoungestPerson(personList);
		getYoungestPerson(childList);
	    //getYoungestPerson(objectList);
		
		fill(personList, new Person());
		fill(personList, new Child());
		//fill(personList, new Object());
	}

	public static Person getYoungestPerson(List<? extends Person> list) {
		return null;
	}
	
	public static <T> void fill(List<? super T> list, T obj) {
		// ...
	}
}
