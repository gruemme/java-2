package de.bredex.kurse.java2.io.examples;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;

public class Deserializer {
    
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        //(@body@)
        // Stream zum Deserialisieren aus einer Datei erstellen
        InputStream serialisiert = new FileInputStream("data/serialized.data");
        ObjectInputStream objekte = new ObjectInputStream(serialisiert);
        // Objekt lesen
        boolean beenden = false;
        while (!beenden) {
            try {
                Object objekt = objekte.readObject();
                System.out.println("Neues Objekt gelesen!");
                System.out.println("  Klasse: " + objekt.getClass().getName());
                System.out.println("  Wert: " + objekt);
            } catch (EOFException exception) {
                beenden = true;
            }
        }
        // Stream schliessen
        objekte.close();
        //(@/body@)
    }

}
