package de.bredex.kurse.java2.junit.examples;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class MyNumberUtilTest {

	@Test
	public void testIsEvenGiving10() {
		Assertions.assertTrue(MyNumberUtil.isEven(10));
	}
	
	@Test
	public void testIsEvenGiving13() {
		Assertions.assertFalse(MyNumberUtil.isEven(13));
	}
}
