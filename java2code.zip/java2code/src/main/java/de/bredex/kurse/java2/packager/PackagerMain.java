package de.bredex.kurse.java2.packager;

import javax.swing.JOptionPane;

public class PackagerMain {
	public static void main(String[] args) {

		JOptionPane.showMessageDialog(null, 
				"Applikation wurde gestartet?", "Fertig", JOptionPane.OK_OPTION);
	}
}
