package de.bredex.kurse.java2.threads.examples;
/* Thread1 und Thread2 schreiben beide gleichzeitig. 

Thread1 liest -> c == 0
Thread2 liest -> c == 0  (beide zur gleichen Zeit)

Beide erhöhen um 1 und schreiben den neuen Wert wieder.

Manchmal passiert es, dass Thread2 schreibt, nachdem Thread1 geschrieben hat. -> Werte größer 1000000
*/
public class CounterTest {
	public static void main(String[] args) throws InterruptedException {

		MyCounter counter = new MyCounter();

		Thread thread1 = new Thread(new CounterIncRunnable(counter));
		thread1.setName("add thread");
		thread1.start();

		Thread thread2 = new Thread(new CounterIncRunnable(counter));
		thread2.setName("add thread2");
		thread2.start();

		thread1.join();
		thread2.join();

		System.out.println(counter.value());
	}
}

class CounterIncRunnable implements Runnable {
	private MyCounter counter;

	public CounterIncRunnable(MyCounter counter) {
		this.counter = counter;
	}

	public void run() {
		for (int i = 0; i < 1000000; i++) {
			counter.increment();
		}
	}
}

class MyCounter {
	private int  c = 0;

	// ohne synchronized Entsteht eine RaceCondidion. (synchronized schränkt den
	// Zufgriff auf nur einen Thread ein)
	public synchronized void increment() 
	{
		// public synchronized void increment() {
		c++;
	}

	public void decrement() {
		c--;
	}

	public int value() {
		return c;
	}
}