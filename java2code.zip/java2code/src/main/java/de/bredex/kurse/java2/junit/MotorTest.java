package de.bredex.kurse.java2.junit;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class MotorTest {

	private static Motor motor;

	@BeforeAll
	public static void createMotor() {
		motor = new Motor();
		System.out.println("Motor created.");
	}

	@AfterAll
	public static void removeMotor() {
		motor = null;
		System.out.println("Motor removed.");
	}

	@BeforeEach
	public void startMotorBeforeTest() {
		motor.start();
	}

	@AfterEach
	public void stopMotorAfterTest() {
		motor.stop();
	}

	@Test
	public void testAccelerateBy3000() {
		assertEquals(1000, motor.getRoundsPerMinute());
		motor.accelerateBy(3000);
		assertEquals(4000, motor.getRoundsPerMinute());
	}

	@Test
	public void testAccelerateByMinus500() {
		assertEquals(1000, motor.getRoundsPerMinute());
		motor.accelerateBy(-500);
		assertEquals(0, motor.getRoundsPerMinute());
	}
	
}
