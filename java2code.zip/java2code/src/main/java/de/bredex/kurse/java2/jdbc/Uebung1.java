package de.bredex.kurse.java2.jdbc;

import java.sql.SQLException;

public class Uebung1 {

    public void connect() throws SQLException {
        // Treiber: org.h2.Driver
        // JDBC-URL: jdbc:h2:test
        // Nutzer: sa
        // leeres Passwort
    }
    
    public void disconnect() throws SQLException {
    }
    
    public void clearDatabase() throws SQLException {
        // drop table if exists attendees, seminar, person
    }
    
    public void createDatabase() throws SQLException {
        // create table person(id int primary key, last varchar(255), first varchar(255))
        // create table seminar(id int primary key, title varchar(255))
        // create table attendees(seminarid int, personid int)
    }
    
    public int insertPerson(String last, String first) throws SQLException {
        // insert into person values (<ID>, '<LAST>', '<FIRST>')
    	return 0;
    }

    public int insertSeminar(String title) throws SQLException {
        // insert into seminar values (<ID>, '<TITLE>')
        return 0;
    }
    
    public void assignToSeminar(int seminarID, int personID) throws SQLException {
        // insert into attendees values(<SEMINARID>, <PERSONID>)
    }
    
    public Object[] getFirstResult(String selectSQL) throws SQLException {
        // gegebenes SQL ausfuehren
        // ersten Eintrag des Ergebnisses in ein Array umwandeln
        return null;
    }

}
