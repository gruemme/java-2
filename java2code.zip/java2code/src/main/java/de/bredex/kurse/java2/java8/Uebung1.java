package de.bredex.kurse.java2.java8;

import java.time.LocalDate;
import java.util.List;

public class Uebung1 {
    
    public int getMonthOfThirdDateAfter2000(List<LocalDate> dateList) {
        return 0;
    }
    
}
