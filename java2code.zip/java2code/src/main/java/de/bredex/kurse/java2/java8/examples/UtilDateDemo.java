package de.bredex.kurse.java2.java8.examples;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

public class UtilDateDemo {

	public static void main(String[] args) {

		createNewUtilDate();
		createNewGregorianClandar();
	}

	private static void createNewGregorianClandar() {
		
		int year = 2016;
		int month = Calendar.DECEMBER;
		int dayOfMonth = 6;
		int hourOfDay = 13;
		int minute = 15;
		
		GregorianCalendar gc1 = new GregorianCalendar(year, month,dayOfMonth,hourOfDay,minute);
    	SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy -- HH:mm");
    	String format = sdf.format(gc1.getTime());
    	System.out.println(format);

    	SimpleDateFormat sdf2 = new SimpleDateFormat("dd.MM.yyyy -- hh:mm");
    	gc1.setTimeZone(TimeZone.getTimeZone("GMT-8:00"));
    	String format2 = sdf2.format(gc1.getTime());
    	System.out.println(format2);
    	
    	gc1.add(GregorianCalendar.MONTH, 1);
    	String format3 = sdf2.format(gc1.getTime());
    	System.out.println(format3);

	}

	private static Date createNewUtilDate() {
		Date d = new Date();
    	
    	SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
		try {
			Date parsedDate = sdf.parse("26.09.2016");
			System.out.println(parsedDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}	
		return d;
	}

}
