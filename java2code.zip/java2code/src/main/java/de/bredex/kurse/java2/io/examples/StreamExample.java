package de.bredex.kurse.java2.io.examples;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class StreamExample {
	public static void main(String[] args) {
				
		List<String> stringListe = new ArrayList<>();
		stringListe.add("Golf");
		stringListe.add("Passat");
		stringListe.add("Polo");
		stringListe.add("T5");
		stringListe.add("T6");
		stringListe.add("T1");
		stringListe.add("T4");
		stringListe.add("T2");
		stringListe.add("T3");
		stringListe.add("Lupo");
		
		example1(stringListe);
		
//		example2(stringListe);
		
//		List<String> example3 = example3(stringListe);
//		
//		for (String s : example3) {
//			System.out.println(s);
//		}
		
	}
	
	private static void example1(List<String> stringListe) {
		
		stringListe.stream().filter(t -> t.startsWith("T"))
		.sorted()
		.forEach(givenString -> System.out.println(givenString));
	}
	
	
	private static void example2(List<String> stringListe) {
		stringListe.stream()
		.findFirst()
		.ifPresent(t -> System.out.println("findFirst: " + t));
	}
	private static List<String> example3(List<String> stringListe) {
		return stringListe.stream().filter(new Predicate<String>() {
			@Override
			public boolean test(String e) {
				return e.startsWith("L");
			}
		}).collect(Collectors.toList());

	}
}
