package de.bredex.kurse.java2.io.examples;

public class  SimpleSystemReadEinzelCharacter {

	public static void main(String[] args) throws Exception {
		
		System.out.println("Enter a Character: ");

		// readByte ist die ASCII - Repräsentation des eingegebenen Characters
		int readByte = System.in.read();
		
		System.out.println("ASCII-Code: " + readByte);
		System.out.println("Eingegebenes Zeichen: " + (char) readByte);
		
	}
}
